x = 'salam alekum'
x = x.split()
print(x)
x = '+'.join(x)
print(x)
