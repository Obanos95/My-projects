r = 1
while True:
    r = r*2
    print(r)
