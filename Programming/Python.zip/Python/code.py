x = [1,2,3,4,5]
fx = frozenset(x)
fx[1] = 4
print(fx)
