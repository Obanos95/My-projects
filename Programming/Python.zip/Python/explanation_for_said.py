# Explanation of lists
'''ls = ['13', 13, 12.6, 15, 'Salam', 40.23]
print(len(ls[0]))'''

# Generators
'''a=[x for x in range(1,12)]
print(a)'''

# Functions
'''def said():
    print('Hello')
    print('Hello')

said()
said()
said()'''


