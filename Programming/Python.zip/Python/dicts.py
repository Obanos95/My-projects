diction = {1:'Hello','w':'Work'}
print(diction[1])
print(diction['w'])
