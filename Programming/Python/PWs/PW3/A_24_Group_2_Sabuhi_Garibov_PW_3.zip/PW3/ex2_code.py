def sp1(a):
    b = 5
    return a + b

def sp2(a):
    return 2 * a

def main():
    print(sp1(2))
    print(sp2(3))
    a = 6
    print(sp1(a=a))
    print(b)
main()
