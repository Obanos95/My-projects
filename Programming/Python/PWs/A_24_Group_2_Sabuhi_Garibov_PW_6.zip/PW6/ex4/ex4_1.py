fraction_dict = {'numerator':2,
                 'denominator':5}
print(f'{fraction_dict["numerator"]}/{fraction_dict["denominator"]}')